package team.woo.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import team.woo.algorithm.TaskAllocation;
import team.woo.domain.Schedule;
import team.woo.domain.ScheduleService;
import team.woo.member.Member;
import team.woo.member.MemberRepository;
import team.woo.session.SessionConst;

import team.woo.domain.ScheduleRepository;
import team.woo.session.SessionManager;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
@RequiredArgsConstructor
public class HomeController {

    private final ScheduleRepository scheduleRepository;
    private final MemberRepository memberRepository;
    private final ScheduleService scheduleService;
    private static final Logger logger = LoggerFactory.getLogger(ScheduleController.class);
    private final SessionManager sessionManager;

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("pageTitle", "메인 페이지 입니다.");
        return "index";
    }

    @GetMapping("/cabinet")
    public String cabinet(Model model, HttpServletRequest request) {
        Long memberId = (Long) request.getSession().getAttribute("memberId");
        List<Schedule> schedules = (memberId != null) ? scheduleService.getSchedulesByMemberId(memberId) : List.of();
        model.addAttribute("schedules", schedules);
        return "/cabinet";
    }

    @GetMapping("/check")
    public String check(Model model) {
        model.addAttribute("pageTitle", "Check 페이지 입니다.");
        return "check";
    }

    @GetMapping("/about")
    public String about(Model model) {
        model.addAttribute("pageTitle", "About 페이지 입니다.");
        return "about";
    }

    @GetMapping("/result_ts/{id}")
    public String resultTs(@PathVariable Long id, Model model, HttpServletRequest request) {
        Member loginMember = (Member) sessionManager.getSession(request);
        if (loginMember != null) {
            logger.info("세션 확인: 사용자 ID = {}", loginMember.getId());
            model.addAttribute("loginMember", loginMember);
        } else {
            logger.warn("세션에 LOGIN_MEMBER 정보가 없음.");
            return "redirect:/login"; // 세션이 없을 경우 로그인 페이지로 리다이렉트
        }

        Schedule schedule = scheduleService.getSchedule(id);
        model.addAttribute("schedule", schedule);
        model.addAttribute("adjustDays", schedule.getAdjustDays());
        model.addAttribute("adjustTime", schedule.getAdjustTime());

        return "result_ts";
    }


    @GetMapping("/calendarCheck/{loginId}/{id}")
    public String calendarCheck(@PathVariable String loginId, @PathVariable Long id, Model model) {
        Schedule schedule = scheduleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid schedule Id: " + id));

        model.addAttribute("adjustDays", schedule.getAdjustDays());
        model.addAttribute("adjustTime", schedule.getAdjustTime());
        model.addAttribute("startTime", schedule.getStartTime());
        model.addAttribute("deadLine", schedule.getDeadLine());
        model.addAttribute("id", id);
        model.addAttribute("scheduleName", schedule.getName());

        return "calendarCheck";
    }
}