package team.woo.domain;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import team.woo.member.Member;
import team.woo.member.MemberRepository;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ScheduleService {

    private final ScheduleRepository scheduleRepository;
    private final MemberRepository memberRepository;

    @Transactional
    public Schedule saveSchedule(Schedule schedule, Long memberId) {
        if (memberId != null) {
            Member member = memberRepository.findById(memberId)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid member Id: " + memberId));
            schedule.setMember(member);
        }
        return scheduleRepository.save(schedule);
    }

    // 매개변수로 직접 데이터를 받아 Schedule 객체를 생성하고 저장하는 메서드
    @Transactional
    public Schedule saveSchedule(String name, LocalDate startTime, LocalDate deadline, int difficulty, int urgency, int importance, String restTime, int stress, String preferenceTime, Long memberId) {
        Schedule schedule = new Schedule(name, startTime, deadline, difficulty, importance, urgency, restTime, preferenceTime, stress);
        return saveSchedule(schedule, memberId);
    }

    @Transactional
    public Schedule updateSchedule(Schedule schedule) {
        return scheduleRepository.save(schedule);
    }

    @Transactional(readOnly = true)
    public Schedule getSchedule(Long id) {
        return scheduleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid schedule Id: " + id));
    }

    @Transactional(readOnly = true)
    public List<Schedule> getSchedulesByMemberId(Long memberId) {
        return scheduleRepository.findByMemberId(memberId);
    }
}